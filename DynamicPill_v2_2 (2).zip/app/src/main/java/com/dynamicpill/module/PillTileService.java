package com.dynamicpill.module;

import android.content.SharedPreferences;
import android.graphics.drawable.Icon;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** One Control Center tile: turns the pill AND the line on or off together. */
public class PillTileService extends TileService {

    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    private SharedPreferences prefs() {
        try {
            return getSharedPreferences(PillController.PREF_FILE, MODE_WORLD_READABLE);
        } catch (Throwable t) {
            return getSharedPreferences(PillController.PREF_FILE, MODE_PRIVATE);
        }
    }

    private boolean isOn(SharedPreferences sp) {
        return sp.getBoolean(PillController.K_ENABLED, true) || sp.getBoolean(PillController.K_LINE_ON, true);
    }

    @Override
    public void onStartListening() {
        refresh();
    }

    @Override
    public void onClick() {
        SharedPreferences sp = prefs();
        boolean on = !isOn(sp);
        sp.edit()
                .putBoolean(PillController.K_ENABLED, on)
                .putBoolean(PillController.K_LINE_ON, on)
                .apply();
        refresh();
    }

    private void refresh() {
        Tile t = getQsTile();
        if (t == null) return;
        t.setLabel("Dynamic Pill");
        t.setIcon(Icon.createWithResource(this, R.drawable.ic_pill));
        t.setState(isOn(prefs()) ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.updateTile();
    }
}
