package com.dynamicpill.module;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** iOS style toggle: rounded track and a white round thumb that slides. */
public class IosSwitch extends View {
    public interface Listener { void onChanged(boolean on); }

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumb = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final int offColor, onColor;
    private boolean on;
    private float pos;           // 0 = off, 1 = on
    private ValueAnimator anim;
    private Listener listener;

    public IosSwitch(Context c, int offColor, int onColor) {
        super(c);
        this.offColor = offColor;
        this.onColor = onColor;
        thumb.setColor(0xFFFFFFFF);
        thumb.setShadowLayer(2f, 0f, 1f, 0x33000000);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        setOnClickListener(v -> setChecked(!on, true));
    }

    public void setListener(Listener l) { listener = l; }

    public void setChecked(boolean v) { setChecked(v, false); }

    private void setChecked(boolean v, boolean notify) {
        if (v == on) return;
        on = v;
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(pos, on ? 1f : 0f);
        anim.setDuration(180);
        anim.addUpdateListener(a -> { pos = (Float) a.getAnimatedValue(); invalidate(); });
        anim.start();
        if (notify && listener != null) listener.onChanged(on);
    }

    public void snap(boolean v) {
        on = v;
        pos = v ? 1f : 0f;
        invalidate();
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        float d = getResources().getDisplayMetrics().density;
        setMeasuredDimension(Math.round(52 * d), Math.round(32 * d));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float r = h / 2f;
        int c = (Integer) new android.animation.ArgbEvaluator().evaluate(pos, offColor, onColor);
        track.setColor(c);
        rect.set(0, 0, w, h);
        canvas.drawRoundRect(rect, r, r, track);
        float pad = h * 0.08f;
        float tr = r - pad;
        float cx = r + (w - h) * pos;
        canvas.drawCircle(cx, r, tr, thumb);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (anim != null) anim.cancel();
        pos = on ? 1f : 0f;
    }
}
